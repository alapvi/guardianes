/* Guardianes de la Tierra — web estática bilingüe sin servicios externos */
'use strict';

const texts = {
  es: {
    skip: 'Saltar al contenido', brand: 'GUARDIANES <small>DE LA TIERRA</small>',
    metaDescription: 'Descubre cómo nacieron seis guardianes educativos: del boceto al modelado 3D, la impresión y la pintura artesanal.',
    navProject: 'Proyecto', navMaking: 'Making of', navGuardians: 'Guardianes', navClass: 'El aula',
    heroEyebrow: 'UNA CREACIÓN ORIGINAL · SEIS MISIONES', heroTitle1: 'Los Guardianes', heroTitle2: 'de la Tierra',
    heroTagline: 'De un boceto a una aventura educativa.',
    heroCopy: 'Seis personajes únicos, diseñados, impresos en 3D y pintados a mano para acompañar el aprendizaje y dar vida a las situaciones de aprendizaje.',
    heroCTA: 'Descubre cómo nacieron', heroPhotoLabel: 'HECHOS A MANO, DESDE CERO',
    heroImageAlt: 'Los seis guardianes terminados, dispuestos en una vitrina de madera',
    heroBottom: ' UNA HISTORIA DE CREACIÓN', scroll: 'DESLIZA PARA DESCUBRIR',
    projectKicker: '01 · EL ORIGEN', projectTitle: 'Una idea que <em>cobra vida.</em>',
    projectIntro: 'Los guardianes nacen de la necesidad de crear recursos propios que conecten con el alumnado. Cada personaje representa una misión ambiental y da sentido a las experiencias de aprendizaje.',
    value1Title: 'Creación propia', value1Copy: 'De la primera idea a la figura terminada. Nada de personajes comprados.',
    value2Title: 'Identidad educativa', value2Copy: 'Seis guardianes que acompañan las situaciones de aprendizaje y sus retos.',
    value3Title: 'Compromiso ambiental', value3Copy: 'Historias cercanas para despertar curiosidad y fomentar el cuidado del planeta.',
    makingKicker: '02 · ASÍ SE HICIERON', makingTitle: 'El arte de hacerlos <em>realidad.</em>',
    makingIntro: 'No nacieron en una tienda. Cada guardián recorrió un camino: imaginar, diseñar, imprimir y pintar. Este es nuestro making of.',
    step1Label: 'EL PUNTO DE PARTIDA', step1Title: 'Primero, una idea',
    step1Copy: 'Todo comienza con un boceto: imaginar el aspecto, los detalles y la personalidad de cada guardián.',
    step1Pending: 'El boceto original se incorporará aquí cuando esté disponible.', sketchWord: 'IMAGINAR',
    step2Label: 'DEL PAPEL A LA PANTALLA', step2Title: 'El diseño toma forma',
    step2Copy: 'El personaje se modela digitalmente y se obtiene un archivo STL, que contiene la geometría necesaria para preparar la impresión 3D.',
    step2Detail: 'Imagen real del modelo de Chispas antes de imprimirlo.', step2Alt: 'Modelo tridimensional en gris del guardián Chispas', step2Caption: 'CHISPAS · MODELO DIGITAL',
    step3Label: 'DE LO DIGITAL A LO REAL', step3Title: 'La magia de imprimir en 3D',
    step3Copy: 'Un programa de laminado transforma el modelo en instrucciones para la impresora. Capa a capa, aparece la figura física.',
    step3Detail: 'Grabaciones reales del proceso de fabricación.', step3Alt: 'Figura en proceso de fabricación dentro de una impresora 3D',
    step3Caption: 'IMPRESIÓN EN MARCHA', noVideo: 'Tu navegador no admite este vídeo.', video1: 'Impresión · Vista 1', video2: 'Impresión · Vista 2',
    step4Label: 'EL TRABAJO ARTESANAL', step4Title: 'Pincelada a pincelada',
    step4Copy: 'Las figuras recién impresas se preparan y reciben color a mano. Cada detalle aporta expresión y personalidad.',
    step4aAlt: 'Dos figuras blancas terminadas de imprimir, todavía sin pintar', step4bAlt: 'Flora en proceso de pintura con pinceles y paleta de colores',
    step4aCaption: 'ANTES DEL COLOR', step4bCaption: 'PINTURA A MANO',
    step5Label: 'EL RESULTADO FINAL', step5Title: '¡Los guardianes cobran vida!',
    step5Copy: 'Después de diseñar, fabricar y pintar, cada personaje está listo para acompañar una nueva aventura educativa.',
    step5Link: 'Conoce a los seis guardianes', step5Alt: 'Flora terminada, con detalles verdes en sus ramas y ojos pintados', step5Caption: 'FLORA · RESULTADO FINAL',
    galleryKicker: '03 · CONOCE A LOS PROTAGONISTAS', galleryTitle: 'Seis guardianes.<br><em>Seis misiones.</em>',
    galleryIntro: 'Cada uno tiene una personalidad, un propósito y una historia que contar. Toca una tarjeta para conocer su misión.',
    trastoShort: 'Reciclaje y residuos', floraShort: 'Bosques y naturaleza', dorisShort: 'Mares sin plásticos',
    aerisShort: 'Aire limpio', gotaShort: 'Agua responsable', chispasShort: 'Energía responsable',
    classKicker: '04 · DEL TALLER AL AULA', classTitle: 'Creados para <em>aprender.</em>',
    classCopy: 'Los guardianes son recursos originales elaborados para acompañar las situaciones de aprendizaje. Sus formas, colores y misiones convierten los retos ambientales en propuestas visuales y cercanas.',
    classNote: 'El diseño digital y la impresión 3D forman parte de la preparación del material. En el aula, el pintado y la personalización de figuras previamente impresas podrían convertirse en una actividad artística adaptada a 1.º de Primaria, con materiales adecuados y supervisión.',
    closingEyebrow: 'EL COMIENZO DE UNA AVENTURA', closingTitle: 'No los compramos.<br><em>Los hicimos realidad.</em>',
    closingCopy: 'Los imaginamos, los diseñamos, los imprimimos y los pintamos. Ahora están preparados para acompañar a los pequeños guardianes de nuestro planeta.',
    backTop: 'Volver al inicio', footerTitle: 'GUARDIANES DE LA TIERRA', footerSubtitle: 'Un proyecto educativo de creación propia.',
    dialogKicker: 'CONOCE AL GUARDIÁN', dialogMissionLabel: 'SU MISIÓN', dialogClose: 'Cerrar', dialogPrev: 'Anterior guardián', dialogNext: 'Siguiente guardián',
    altTrasto: 'Trasto, guardián del reciclaje', altFlora: 'Flora, guardiana del bosque', altDoris: 'Doris, guardiana del mar',
    altAeris: 'Aeris, guardián del aire', altGota: 'Gota, guardiana del agua', altChispas: 'Chispas, guardián de la energía',
    missions: {
      trasto: 'Nos invita a reducir residuos, reutilizar materiales y descubrir cómo el reciclaje ayuda a cuidar nuestro entorno.',
      flora: 'Protege los bosques y las plantas. Nos recuerda que cada árbol y cada ser vivo tienen un lugar importante en la naturaleza.',
      doris: 'Nos anima a proteger los mares y a evitar que los plásticos y otros residuos lleguen al agua y dañen a sus habitantes.',
      aeris: 'Nos ayuda a comprender por qué es importante respirar aire limpio y qué pequeñas acciones pueden reducir la contaminación.',
      gota: 'Nos enseña que el agua es un recurso valioso y nos anima a utilizarla con responsabilidad en nuestra vida diaria.',
      chispas: 'Nos invita a descubrir de dónde viene la energía y cómo podemos ahorrar electricidad y utilizarla de forma responsable.'
    }
  },
  va: {
    skip: 'Ves al contingut', brand: 'GUARDIANS <small>DE LA TERRA</small>',
    metaDescription: 'Descobrix com van nàixer sis guardians educatius: de l’esbós al modelatge 3D, la impressió i la pintura artesanal.',
    navProject: 'Projecte', navMaking: 'Making of', navGuardians: 'Guardians', navClass: 'L’aula',
    heroEyebrow: 'UNA CREACIÓ ORIGINAL · SIS MISSIONS', heroTitle1: 'Els Guardians', heroTitle2: 'de la Terra',
    heroTagline: 'D’un esbós a una aventura educativa.',
    heroCopy: 'Sis personatges únics, dissenyats, impresos en 3D i pintats a mà per a acompanyar l’aprenentatge i donar vida a les situacions d’aprenentatge.',
    heroCTA: 'Descobrix com van nàixer', heroPhotoLabel: 'FETS A MÀ, DES DE ZERO',
    heroImageAlt: 'Els sis guardians acabats, col·locats en una vitrina de fusta',
    heroBottom: ' UNA HISTÒRIA DE CREACIÓ', scroll: 'LLISCA PER A DESCOBRIR',
    projectKicker: '01 · L’ORIGEN', projectTitle: 'Una idea que <em>cobra vida.</em>',
    projectIntro: 'Els guardians naixen de la necessitat de crear recursos propis que connecten amb l’alumnat. Cada personatge representa una missió ambiental i dona sentit a les experiències d’aprenentatge.',
    value1Title: 'Creació pròpia', value1Copy: 'De la primera idea a la figura acabada. Cap personatge comprat.',
    value2Title: 'Identitat educativa', value2Copy: 'Sis guardians que acompanyen les situacions d’aprenentatge i els seus reptes.',
    value3Title: 'Compromís ambiental', value3Copy: 'Històries pròximes per a despertar la curiositat i fomentar la cura del planeta.',
    makingKicker: '02 · AIXÍ ES VAN FER', makingTitle: 'L’art de fer-los <em>realitat.</em>',
    makingIntro: 'No van nàixer en una botiga. Cada guardià va recórrer un camí: imaginar, dissenyar, imprimir i pintar. Este és el nostre making of.',
    step1Label: 'EL PUNT DE PARTIDA', step1Title: 'Primer, una idea',
    step1Copy: 'Tot comença amb un esbós: imaginar l’aspecte, els detalls i la personalitat de cada guardià.',
    step1Pending: 'L’esbós original s’incorporarà ací quan estiga disponible.', sketchWord: 'IMAGINAR',
    step2Label: 'DEL PAPER A LA PANTALLA', step2Title: 'El disseny pren forma',
    step2Copy: 'El personatge es modela digitalment i s’obté un arxiu STL, que conté la geometria necessària per a preparar la impressió 3D.',
    step2Detail: 'Imatge real del model de Chispas abans d’imprimir-lo.', step2Alt: 'Model tridimensional gris del guardià Chispas', step2Caption: 'CHISPAS · MODEL DIGITAL',
    step3Label: 'DEL DIGITAL AL REAL', step3Title: 'La màgia d’imprimir en 3D',
    step3Copy: 'Un programa de laminatge transforma el model en instruccions per a la impressora. Capa a capa, apareix la figura física.',
    step3Detail: 'Gravacions reals del procés de fabricació.', step3Alt: 'Figura en procés de fabricació dins d’una impressora 3D',
    step3Caption: 'IMPRESSIÓ EN MARXA', noVideo: 'El teu navegador no admet este vídeo.', video1: 'Impressió · Vista 1', video2: 'Impressió · Vista 2',
    step4Label: 'EL TREBALL ARTESANAL', step4Title: 'Pinzellada a pinzellada',
    step4Copy: 'Les figures acabades d’imprimir es preparen i reben color a mà. Cada detall aporta expressió i personalitat.',
    step4aAlt: 'Dues figures blanques acabades d’imprimir, encara sense pintar', step4bAlt: 'Flora en procés de pintura amb pinzells i paleta de colors',
    step4aCaption: 'ABANS DEL COLOR', step4bCaption: 'PINTURA A MÀ',
    step5Label: 'EL RESULTAT FINAL', step5Title: 'Els guardians cobren vida!',
    step5Copy: 'Després de dissenyar, fabricar i pintar, cada personatge està preparat per a acompanyar una nova aventura educativa.',
    step5Link: 'Coneix els sis guardians', step5Alt: 'Flora acabada, amb detalls verds a les branques i els ulls pintats', step5Caption: 'FLORA · RESULTAT FINAL',
    galleryKicker: '03 · CONEIX ELS PROTAGONISTES', galleryTitle: 'Sis guardians.<br><em>Sis missions.</em>',
    galleryIntro: 'Cada un té una personalitat, un propòsit i una història per contar. Toca una targeta per a conéixer la seua missió.',
    trastoShort: 'Reciclatge i residus', floraShort: 'Boscos i natura', dorisShort: 'Mars sense plàstics',
    aerisShort: 'Aire net', gotaShort: 'Ús responsable de l’aigua', chispasShort: 'Energia responsable',
    classKicker: '04 · DEL TALLER A L’AULA', classTitle: 'Creats per a <em>aprendre.</em>',
    classCopy: 'Els guardians són recursos originals elaborats per a acompanyar les situacions d’aprenentatge. Les seues formes, colors i missions convertixen els reptes ambientals en propostes visuals i pròximes.',
    classNote: 'El disseny digital i la impressió 3D formen part de la preparació del material. A l’aula, la pintura i la personalització de figures prèviament impreses podrien convertir-se en una activitat artística adaptada a 1r de Primària, amb materials adequats i supervisió.',
    closingEyebrow: 'EL COMENÇAMENT D’UNA AVENTURA', closingTitle: 'No els vam comprar.<br><em>Els vam fer realitat.</em>',
    closingCopy: 'Els vam imaginar, els vam dissenyar, els vam imprimir i els vam pintar. Ara estan preparats per a acompanyar els menuts guardians del nostre planeta.',
    backTop: 'Torna a l’inici', footerTitle: 'GUARDIANS DE LA TERRA', footerSubtitle: 'Un projecte educatiu de creació pròpia.',
    dialogKicker: 'CONEIX EL GUARDIÀ', dialogMissionLabel: 'LA SEUA MISSIÓ', dialogClose: 'Tancar', dialogPrev: 'Guardià anterior', dialogNext: 'Guardià següent',
    altTrasto: 'Trasto, guardià del reciclatge', altFlora: 'Flora, guardiana del bosc', altDoris: 'Doris, guardiana de la mar',
    altAeris: 'Aeris, guardià de l’aire', altGota: 'Gota, guardiana de l’aigua', altChispas: 'Chispas, guardià de l’energia',
    missions: {
      trasto: 'Ens convida a reduir residus, reutilitzar materials i descobrir com el reciclatge ajuda a cuidar el nostre entorn.',
      flora: 'Protegix els boscos i les plantes. Ens recorda que cada arbre i cada ésser viu tenen un lloc important en la natura.',
      doris: 'Ens anima a protegir les mars i a evitar que els plàstics i altres residus arriben a l’aigua i perjudiquen els seus habitants.',
      aeris: 'Ens ajuda a comprendre per què és important respirar aire net i quines accions senzilles poden reduir la contaminació.',
      gota: 'Ens ensenya que l’aigua és un recurs valuós i ens anima a utilitzar-la amb responsabilitat en el dia a dia.',
      chispas: 'Ens convida a descobrir d’on ve l’energia i com podem estalviar electricitat i utilitzar-la de manera responsable.'
    }
  }
};

const guardianInfo = [
  { id: 'trasto', name: 'Trasto', index: '01', photo: 'guardian1.jpeg' },
  { id: 'flora', name: 'Flora', index: '02', photo: 'guardian2.jpeg' },
  { id: 'doris', name: 'Doris', index: '03', photo: 'guardian3.jpeg' },
  { id: 'aeris', name: 'Aeris', index: '04', photo: 'guardian4.jpeg' },
  { id: 'gota', name: 'Gota', index: '05', photo: 'guardian5.jpeg' },
  { id: 'chispas', name: 'Chispas', index: '06', photo: 'guardian6.jpeg' }
];

let currentLanguage = 'es';
let currentGuardian = 0;
let previousFocus = null;
const dialog = document.querySelector('#guardian-dialog');
const dialogImage = document.querySelector('#dialog-image');

function setLanguage(lang) {
  currentLanguage = lang === 'va' ? 'va' : 'es';
  const t = texts[currentLanguage];
  document.documentElement.lang = currentLanguage === 'va' ? 'ca-valencia' : 'es';
  document.title = currentLanguage === 'va' ? 'Guardians de la Terra · Making of' : 'Guardianes de la Tierra · Making of';
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    if (key === 'brand') el.innerHTML = t.brand; // Texto propio, no contenido de usuario.
    else if (typeof t[key] === 'string') el.textContent = t[key];
  });
  document.querySelectorAll('[data-i18n-html]').forEach(el => {
    const key = el.dataset.i18nHtml;
    if (typeof t[key] === 'string') el.innerHTML = t[key]; // Traducciones locales, constantes.
  });
  document.querySelectorAll('[data-i18n-attr]').forEach(el => {
    const [attr, key] = el.dataset.i18nAttr.split(':');
    if (['alt', 'content', 'aria-label'].includes(attr) && typeof t[key] === 'string') el.setAttribute(attr, t[key]);
  });
  document.querySelectorAll('.lang-btn').forEach(btn => {
    const active = btn.dataset.lang === currentLanguage;
    btn.classList.toggle('is-active', active);
    btn.setAttribute('aria-pressed', String(active));
  });
  document.querySelector('#dialog-close').setAttribute('aria-label', t.dialogClose);
  document.querySelector('#dialog-close').setAttribute('title', t.dialogClose);
  document.querySelector('#dialog-prev').setAttribute('aria-label', t.dialogPrev);
  document.querySelector('#dialog-next').setAttribute('aria-label', t.dialogNext);
  if (dialog.open) showGuardian(currentGuardian);
  try { localStorage.setItem('guardianes-lang', currentLanguage); } catch (_error) { /* Preferencia opcional. */ }
}

function showGuardian(index) {
  currentGuardian = (index + guardianInfo.length) % guardianInfo.length;
  const g = guardianInfo[currentGuardian];
  const t = texts[currentLanguage];
  dialogImage.src = 'assets/img/guardianes/' + g.photo;
  dialogImage.alt = t['alt' + g.name];
  document.querySelector('#dialog-title').textContent = g.name;
  document.querySelector('#dialog-mission').textContent = t.missions[g.id];
  document.querySelector('#dialog-count').textContent = g.index + ' / 06';
}

function openGuardian(index) {
  previousFocus = document.activeElement;
  showGuardian(index);
  dialog.showModal();
  document.body.classList.add('modal-open');
  document.querySelector('#dialog-close').focus();
}

const cards = document.querySelectorAll('[data-guardian]');
cards.forEach((card, index) => card.addEventListener('click', () => openGuardian(index)));
document.querySelector('#dialog-close').addEventListener('click', () => dialog.close());
document.querySelector('#dialog-prev').addEventListener('click', () => showGuardian(currentGuardian - 1));
document.querySelector('#dialog-next').addEventListener('click', () => showGuardian(currentGuardian + 1));
dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
dialog.addEventListener('close', () => {
  document.body.classList.remove('modal-open');
  if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
});
dialog.addEventListener('keydown', event => {
  if (event.key === 'ArrowRight') showGuardian(currentGuardian + 1);
  if (event.key === 'ArrowLeft') showGuardian(currentGuardian - 1);
});

document.querySelectorAll('.lang-btn').forEach(btn => btn.addEventListener('click', () => setLanguage(btn.dataset.lang)));
const requestedLang = new URLSearchParams(location.search).get('lang');
let savedLang = null;
try { savedLang = localStorage.getItem('guardianes-lang'); } catch (_error) { /* Preferencia opcional. */ }
setLanguage(requestedLang === 'va' || requestedLang === 'es' ? requestedLang : (savedLang || 'es'));

// Los efectos nunca bloquean los contenidos: respetamos la reducción de movimiento.
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const nodes = [...document.querySelectorAll('.reveal')];
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
    });
  }, { threshold: .06, rootMargin: '0px 0px 55px 0px' });
  document.documentElement.classList.add('has-js');
  nodes.forEach(node => observer.observe(node));
}
