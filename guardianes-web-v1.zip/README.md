# Guardianes de la Tierra / Guardians de la Terra

Web estática bilingüe (castellano y valenciano) dedicada al **making of de seis guardianes educativos originales**. Incluye fotografías reales de los seis personajes, proceso de modelado/impresión/pintura y dos vídeos del taller.

## Contenido

- Portada con los seis guardianes.
- Finalidad educativa y origen del proyecto.
- Making of en cinco fases: boceto, diseño 3D/STL, impresión, pintura y resultado.
- Galería interactiva de Trasto, Flora, Doris, Aeris, Gota y Chispas.
- Aplicación pedagógica y cierre.
- Selector `ES / VAL`; diseño móvil, accesible y sin servicios externos.

## Despliegue en Cloudflare Workers (Static Assets)

La configuración de despliegue está en `wrangler.jsonc`:

```json
{
  "name": "guardianes",
  "compatibility_date": "2026-11-10",
  "assets": { "directory": "./public", "not_found_handling": "404-page" }
}
```

En **Cloudflare Workers & Pages → guardianes → Settings/Builds** configura:

| Ajuste | Valor |
|---|---|
| Repositorio | `alapvi/guardianes` |
| Rama | `main` |
| Directorio raíz | `/` |
| Build command | vacío |
| Deploy command | `npx wrangler deploy` |

Requiere que el repositorio tenga un commit válido y que la integración GitHub de Cloudflare esté autorizada para ese repositorio. Si falla en **Cloning**, no es un error del HTML ni de Wrangler: comprobar acceso al repositorio, rama y vinculación GitHub.

## Subir el paquete completo a GitHub

El repositorio remoto ya se ha inicializado con un README. **Hay que incorporar todos los archivos** (incluida la carpeta `public/assets` con fotografías y vídeos) para que el Worker pueda funcionar. El paquete ZIP contiene la raíz del proyecto lista para copiar.

Ejemplo con Git en Windows, macOS o Linux (descomprime primero los archivos del ZIP en la carpeta clonada del repositorio, sustituyendo el README inicial):

```bash
git clone https://github.com/alapvi/guardianes.git
cd guardianes
# Copiar aquí los contenidos del ZIP (no el ZIP como un solo archivo).
git add -A
git commit -m "feat: primera version completa de Guardianes de la Tierra"
git push origin main
```

Al hacer `git push`, Cloudflare volverá a compilar si la integración con GitHub está activa. **No se puede dar por publicado hasta verificar un despliegue correcto.**

## Probar localmente

```bash
npm install
npm run dev
```

Para publicar manualmente con Wrangler después de iniciar sesión:

```bash
npm run deploy
```

Para comprobar el sitio sin instalar dependencias, se puede servir `public/` con un servidor HTTP estático, por ejemplo:

```bash
python -m http.server 8080 --directory public
```

## Estructura

```text
public/
  index.html
  assets/
    css/styles.css
    js/main.js
    img/portada/fullguardianes.jpeg
    img/guardianes/guardian1.jpeg ... guardian6.jpeg
    img/proceso/*.png, *.jpeg, poster-*.jpg
    video/impresion-01.mp4, impresion-02.mp4
  favicon.svg
  404.html
  robots.txt
wrangler.jsonc
package.json
```

## Estado de los materiales

- **Pendiente:** boceto original. La primera etapa muestra un recuadro explícito, nunca un dibujo ficticio.
- **Incluido:** captura del modelo digital de Chispas; **STL original aportado por la autora**. No se publica el STL de 45,5 MiB para mantener la página rápida. Se puede optimizar y añadir un visor 3D en una versión posterior.
- **Incluidos:** vídeos reales de impresión 3D con reproducción manual, sin autoplay.
- **Privacidad:** no se incluyen datos personales de estudiantes, cookies de análisis, publicidad ni formularios.

## Materiales y autoría

Fotografías, vídeos y figuras aportados para este proyecto. Mantener la autoría y los permisos pertinentes antes de hacer pública la web. No se han creado modelos de guardianes ni fotografías sintéticas que simulen el proceso de fabricación.
